#include "algogram.h"

// ejecuta el programa, el pedido y ejecuciones de todas las instrucciones dadas por el usuario
// asi como los mensajes de exito u error
void ejecutar_programa(algogram_t *programa);